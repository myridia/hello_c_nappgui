/*
 * NAppGUI Cross-platform C SDK
 * 2015-2025 Francisco Garcia Collado
 * MIT Licence
 * https://nappgui.com/en/legal/license.html
 *
 * File: nappgui.h
 *
 */

/* All-In-One NAppGUI headers */

#include <osapp/osapp.h>
#include <gui/guiall.h>
